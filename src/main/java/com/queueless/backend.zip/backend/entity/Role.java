
package com.queueless.backend.entity;

public enum Role {
    USER,
    ADMIN
}

