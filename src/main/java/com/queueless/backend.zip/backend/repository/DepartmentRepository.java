package com.queueless.backend.repository;

public class DepartmentRepository {
    
}
