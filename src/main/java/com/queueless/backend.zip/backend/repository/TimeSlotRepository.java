package com.queueless.backend.repository;

public class TimeSlotRepository {
    
}
